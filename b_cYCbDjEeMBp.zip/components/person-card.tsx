"use client";

import { Person, TRIP_COST, getColor, getInitials, formatCurrency, getPercentage, getStatus, getProgressColor } from "@/lib/data";

interface PersonCardProps {
  person: Person;
  onClick: () => void;
}

export function PersonCard({ person, onClick }: PersonCardProps) {
  const status = getStatus(person);
  const percentage = getPercentage(person);
  const color = getColor(person.firstName + person.lastName);
  const progressColor = getProgressColor(person);

  const cardClass = status === "funded" 
    ? "border-teal/30 bg-gradient-to-br from-white to-teal-light via-white via-70%" 
    : status === "overfunded" 
    ? "border-gold/40 bg-gradient-to-br from-white to-gold-pale via-white via-70%" 
    : "border-transparent";

  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden bg-white rounded-2xl p-5 cursor-pointer transition-all duration-200 ease-[cubic-bezier(.34,1.56,.64,1)] shadow-[0_4px_24px_rgba(26,43,71,0.10)] border-[1.5px] hover:translate-y-[-4px] hover:shadow-[0_12px_40px_rgba(26,43,71,0.18)] hover:border-clay-light ${cardClass}`}
    >
      {/* Ribbon */}
      {(status === "funded" || status === "overfunded") && (
        <div
          className={`absolute top-3.5 right-[-28px] text-[9px] font-bold tracking-wider uppercase py-1 px-9 rotate-45 ${
            status === "overfunded" ? "bg-gold text-navy" : "bg-teal text-white"
          }`}
        >
          {status === "overfunded" ? "Over Goal" : "Funded ✓"}
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div
          className="w-11 h-11 rounded-full flex items-center justify-center font-serif text-base font-bold text-white shrink-0"
          style={{ backgroundColor: color }}
        >
          {getInitials(person)}
        </div>
        <div className="flex flex-col items-end gap-1">
          {status === "overfunded" && (
            <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-gold-pale text-[#A07820]">
              ⭐ Over Goal
            </span>
          )}
          {status === "funded" && (
            <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-teal-light text-teal">
              ✅ Funded
            </span>
          )}
          {status === "none" && (
            <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-red-pale text-red-soft">
              Not Started
            </span>
          )}
          {status === "partial" && (
            <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-clay-pale text-clay">
              {percentage}%
            </span>
          )}
          {person.role === "Staff" && (
            <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-teal/10 text-teal mt-0.5">
              Staff
            </span>
          )}
        </div>
      </div>

      {/* Name and Role */}
      <div className="font-serif text-lg font-semibold text-navy leading-tight">
        {person.firstName} {person.lastName}
      </div>
      <div className="text-xs text-text-light mt-0.5">{person.role}</div>

      {/* Progress Bar */}
      <div className="mt-3.5 mb-3">
        <div className="h-1.5 bg-sand-dark rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-600 ease-[cubic-bezier(.4,0,.2,1)]"
            style={{ width: `${percentage}%`, backgroundColor: progressColor }}
          />
        </div>
        <div className="flex justify-between text-xs text-text-light mt-1.5">
          <span>
            <strong className="text-text">{formatCurrency(person.totalRaised)}</strong> raised
          </span>
          <span>{formatCurrency(TRIP_COST)} goal</span>
        </div>
      </div>

      {/* Amount Boxes */}
      <div className="flex gap-2.5 mt-3">
        <div className="flex-1 bg-sand rounded-xl p-2 text-center">
          <div className="text-[15px] font-semibold font-serif text-teal">
            {formatCurrency(person.totalRaised)}
          </div>
          <div className="text-[10px] font-medium tracking-wider uppercase text-text-light mt-0.5">
            Raised
          </div>
        </div>
        <div className="flex-1 bg-sand rounded-xl p-2 text-center">
          <div className="text-[15px] font-semibold font-serif text-red-soft">
            {person.balanceOwed > 0 ? formatCurrency(person.balanceOwed) : "—"}
          </div>
          <div className="text-[10px] font-medium tracking-wider uppercase text-text-light mt-0.5">
            Needed
          </div>
        </div>
      </div>

      {/* Donor Count */}
      <div className="text-xs text-text-light mt-2.5 flex items-center gap-1.5">
        <svg width="13" height="13" viewBox="0 0 20 20" fill="none">
          <circle cx="8" cy="7" r="3.5" stroke="#8A9BB5" strokeWidth="1.6" />
          <path d="M2 17c0-3.3 2.7-6 6-6h4c3.3 0 6 2.7 6 6" stroke="#8A9BB5" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
        {person.donors.length} donor{person.donors.length !== 1 ? "s" : ""}
      </div>
      <div className="text-xs font-semibold text-clay mt-1.5">View donor breakdown →</div>
    </div>
  );
}
