"use client";

import { useEffect, useState } from "react";
import { Person, TeamFund, TRIP_COST, getColor, getInitials, formatCurrency, getPercentage, getProgressColor, getSourceTag, Donor } from "@/lib/data";

interface PersonModalProps {
  person: Person | null;
  teamFund: TeamFund | null;
  isOpen: boolean;
  onClose: () => void;
}

function DonorRow({ donor, maxAmount, accentColor, index }: { donor: Donor; maxAmount: number; accentColor: string; index: number }) {
  const initials = donor.name.split(" ").filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  const donorColor = getColor(donor.name);
  const sourceInfo = getSourceTag(donor.source);
  const barWidth = Math.round((donor.amount / maxAmount) * 100);

  return (
    <div 
      className="flex items-center gap-3 py-2.5 border-b border-sand last:border-b-0 animate-fade-up"
      style={{ animationDelay: `${index * 0.04}s` }}
    >
      <div
        className="w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-bold text-white shrink-0"
        style={{ backgroundColor: donorColor }}
      >
        {initials}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-text truncate">{donor.name}</div>
        <span className={`text-[11px] px-1.5 py-0.5 rounded ${sourceInfo.className}`}>
          {sourceInfo.emoji} {sourceInfo.label}
        </span>
        <div className="mt-1">
          <div className="h-[3px] bg-sand-dark rounded-full overflow-hidden">
            <div
              className="h-full rounded-full opacity-50"
              style={{ width: `${barWidth}%`, backgroundColor: accentColor }}
            />
          </div>
        </div>
      </div>
      <div className="font-serif text-base font-semibold shrink-0" style={{ color: accentColor }}>
        {formatCurrency(donor.amount)}
      </div>
    </div>
  );
}

export function PersonModal({ person, teamFund, isOpen, onClose }: PersonModalProps) {
  const [progressWidth, setProgressWidth] = useState(0);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
      const timer = setTimeout(() => {
        if (person) {
          setProgressWidth(getPercentage(person));
        } else if (teamFund) {
          setProgressWidth(100);
        }
      }, 80);
      return () => clearTimeout(timer);
    } else {
      document.body.style.overflow = "";
      setProgressWidth(0);
    }
  }, [isOpen, person, teamFund]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  if (!isOpen) return null;

  const isTeamFund = !!teamFund;
  const name = person ? `${person.firstName} ${person.lastName}` : "General Team Fund";
  const avatarColor = person ? getColor(person.firstName + person.lastName) : "#D4A84B";
  const avatarContent = person ? getInitials(person) : "🏠";
  const progressColor = person ? getProgressColor(person) : "#D4A84B";
  const donors = person ? person.donors : teamFund?.donors || [];
  const maxAmount = Math.max(...donors.map((d) => d.amount), 1);
  const totalRaised = person ? person.totalRaised : teamFund?.totalRaised || 0;
  const percentage = person ? getPercentage(person) : 100;

  let roleText = "";
  if (person) {
    roleText = person.role;
    if (person.role === "Staff") roleText += " · ✅ Fully Covered";
    else if (person.totalRaised > TRIP_COST) roleText += " · ⭐ Over Goal!";
    else if (person.totalRaised >= TRIP_COST) roleText += " · ✅ Fully Funded!";
  } else {
    roleText = "Overflow & undesignated gifts · shared pool";
  }

  let progressText = "";
  if (person) {
    if (person.totalRaised > TRIP_COST) {
      progressText = `${percentage}% — ${formatCurrency(person.totalRaised - TRIP_COST)} over goal! 🎉`;
    } else {
      progressText = `${percentage}% of ${formatCurrency(TRIP_COST)} goal`;
    }
  } else {
    progressText = `${formatCurrency(totalRaised)} collected · no fixed goal`;
  }

  return (
    <div
      className={`fixed inset-0 bg-[rgba(10,20,40,0.55)] backdrop-blur-sm z-[1000] flex items-center justify-center p-5 transition-opacity duration-250 ${
        isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
      } max-sm:items-end max-sm:p-0`}
      onClick={handleOverlayClick}
    >
      <div
        className={`bg-white rounded-3xl w-full max-w-[520px] max-h-[90vh] flex flex-col shadow-[0_30px_80px_rgba(10,20,40,0.35)] transition-transform duration-300 ease-[cubic-bezier(.34,1.4,.64,1)] overflow-hidden ${
          isOpen ? "translate-y-0 scale-100" : "translate-y-6 scale-[0.97]"
        } max-sm:rounded-b-none max-sm:max-w-full`}
      >
        {/* Header */}
        <div className="p-7 pb-5 flex items-start gap-4 border-b border-sand-dark shrink-0">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center font-serif text-xl font-bold text-white shrink-0"
            style={{ backgroundColor: avatarColor }}
          >
            {avatarContent}
          </div>
          <div>
            <div className="font-serif text-[22px] font-bold text-navy leading-tight">{name}</div>
            <div className="text-[13px] text-text-light mt-0.5">{roleText}</div>
          </div>
          <button
            onClick={onClose}
            className="ml-auto bg-sand border-none w-9 h-9 rounded-full cursor-pointer flex items-center justify-center text-lg text-text-mid hover:bg-sand-dark transition-colors shrink-0"
          >
            ✕
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-px bg-sand-dark shrink-0">
          <div className="bg-white p-4 text-center">
            <div className="font-serif text-xl font-bold text-teal leading-none">
              {formatCurrency(totalRaised)}
            </div>
            <div className="text-[10px] font-semibold tracking-wider uppercase text-text-light mt-1">
              Raised
            </div>
          </div>
          <div className="bg-white p-4 text-center">
            <div className="font-serif text-xl font-bold text-red-soft leading-none">
              {person && person.balanceOwed > 0 ? formatCurrency(person.balanceOwed) : "—"}
            </div>
            <div className="text-[10px] font-semibold tracking-wider uppercase text-text-light mt-1">
              Still Needed
            </div>
          </div>
          <div className="bg-white p-4 text-center">
            <div className="font-serif text-xl font-bold text-navy leading-none">
              {donors.length}
            </div>
            <div className="text-[10px] font-semibold tracking-wider uppercase text-text-light mt-1">
              Donors
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="px-7 py-4 shrink-0">
          <div className="h-2.5 bg-sand-dark rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-800 ease-[cubic-bezier(.4,0,.2,1)]"
              style={{ width: `${progressWidth}%`, backgroundColor: progressColor }}
            />
          </div>
          <div className="text-right text-xs font-semibold text-text-mid mt-1.5">{progressText}</div>
        </div>

        {/* Body */}
        <div className="px-7 pb-7 overflow-y-auto flex-1">
          <div className="text-[11px] font-semibold tracking-widest uppercase text-text-light my-4 flex items-center gap-2">
            {isTeamFund ? "Contributors" : "Donor Breakdown"}
            <span className="flex-1 h-px bg-sand-dark" />
          </div>

          {donors.length === 0 ? (
            <div className="bg-sand rounded-xl p-6 text-center text-text-light text-sm">
              No donations recorded yet.
            </div>
          ) : (
            <>
              {donors.map((donor, i) => (
                <DonorRow
                  key={`${donor.name}-${i}`}
                  donor={donor}
                  maxAmount={maxAmount}
                  accentColor={progressColor}
                  index={i}
                />
              ))}
              <div className="pt-3.5 flex justify-between items-center font-semibold text-sm text-text-mid border-t-2 border-sand-dark mt-1">
                <span>Total from {donors.length} donor{donors.length !== 1 ? "s" : ""}</span>
                <span className="font-serif text-lg" style={{ color: progressColor }}>
                  {formatCurrency(donors.reduce((s, d) => s + d.amount, 0))}
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
