"use client";

import { TeamFund, formatCurrency } from "@/lib/data";

interface TeamFundCardProps {
  teamFund: TeamFund;
  onClick: () => void;
}

export function TeamFundCard({ teamFund, onClick }: TeamFundCardProps) {
  return (
    <div
      onClick={onClick}
      className="relative overflow-hidden bg-gradient-to-br from-white via-white to-gold-pale via-60% rounded-2xl p-5 cursor-pointer transition-all duration-200 ease-[cubic-bezier(.34,1.56,.64,1)] shadow-[0_4px_24px_rgba(26,43,71,0.10)] border-2 border-dashed border-gold hover:translate-y-[-4px] hover:shadow-[0_12px_40px_rgba(26,43,71,0.18)] hover:border-solid"
    >
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div className="w-11 h-11 rounded-full flex items-center justify-center text-[22px] bg-gold shrink-0">
          🏠
        </div>
        <span className="text-[11px] font-semibold tracking-wide px-2.5 py-1 rounded-full bg-gold/15 text-[#8A6010]">
          General Fund
        </span>
      </div>

      {/* Name and Description */}
      <div className="font-serif text-lg font-semibold text-navy leading-tight">
        General Team Fund
      </div>
      <div className="text-xs text-text-light mt-0.5">
        Overflow &amp; undesignated gifts · shared pool
      </div>

      {/* Amount Boxes */}
      <div className="flex gap-2.5 mt-4">
        <div className="flex-1 bg-sand rounded-xl p-2 text-center">
          <div className="text-[15px] font-semibold font-serif text-teal">
            {formatCurrency(teamFund.totalRaised)}
          </div>
          <div className="text-[10px] font-medium tracking-wider uppercase text-text-light mt-0.5">
            Collected
          </div>
        </div>
        <div className="flex-1 bg-gold-pale rounded-xl p-2 text-center">
          <div className="text-[15px] font-semibold font-serif text-[#8A6010]">
            {teamFund.donors.length}
          </div>
          <div className="text-[10px] font-medium tracking-wider uppercase text-text-light mt-0.5">
            Contributors
          </div>
        </div>
      </div>

      {/* Contributor Count */}
      <div className="text-xs text-text-light mt-3 flex items-center gap-1.5">
        <svg width="13" height="13" viewBox="0 0 20 20" fill="none">
          <circle cx="8" cy="7" r="3.5" stroke="#8A9BB5" strokeWidth="1.6" />
          <path d="M2 17c0-3.3 2.7-6 6-6h4c3.3 0 6 2.7 6 6" stroke="#8A9BB5" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
        {teamFund.donors.length} contributors
      </div>
      <div className="text-xs font-semibold text-clay mt-1.5">View breakdown →</div>
    </div>
  );
}
