export const TRIP_COST = 1800;

export interface Donor {
  name: string;
  amount: number;
  source: string;
}

export interface Person {
  id: number;
  firstName: string;
  lastName: string;
  role: "Staff" | "Member";
  totalRaised: number;
  tripCost: number;
  balanceOwed: number;
  donors: Donor[];
}

export interface TeamFund {
  totalRaised: number;
  donors: Donor[];
}

export const TEAM_FUND: TeamFund = {
  totalRaised: 150,
  donors: [
    { name: "Martin Ticas", amount: 100, source: "House Build Contribution" },
    { name: "Edith Davis", amount: 50, source: "House Build Contribution" },
  ],
};

export const PEOPLE: Person[] = [
  {
    id: 57069,
    firstName: "Chelsie",
    lastName: "Anderson",
    role: "Staff",
    totalRaised: 1800,
    tripCost: 1800,
    balanceOwed: 0,
    donors: [{ name: "Staff — Fully Covered", amount: 1800, source: "Registration Deposit" }],
  },
  {
    id: 119951,
    firstName: "Howard",
    lastName: "Lee",
    role: "Staff",
    totalRaised: 1800,
    tripCost: 1800,
    balanceOwed: 0,
    donors: [{ name: "Staff — Fully Covered", amount: 1800, source: "Registration Deposit" }],
  },
  {
    id: 78867,
    firstName: "Trevor",
    lastName: "Stripling",
    role: "Staff",
    totalRaised: 1800,
    tripCost: 1800,
    balanceOwed: 0,
    donors: [{ name: "Staff — Fully Covered", amount: 1800, source: "Registration Deposit" }],
  },
  {
    id: 100625,
    firstName: "Raevynn",
    lastName: "Anderson",
    role: "Member",
    totalRaised: 2055,
    tripCost: 1800,
    balanceOwed: 0,
    donors: [
      { name: "April Axelrod", amount: 300, source: "Spaghetti Dinner / Gift Event" },
      { name: "Alex Gonzalez", amount: 200, source: "Spaghetti Dinner / Gift Event" },
      { name: "Howard Lee", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Linda Mahoney", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Erin Gorham", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Kathi Hileman", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Sally Faddis", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Kent/Heather Anderson", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Nancy Eleazarraraz", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Sarah Woolsey", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Chad Anderson", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Raylene & Kevin Anderson", amount: 100, source: "Spaghetti Dinner / Gift Event" },
      { name: "Fiona Xie", amount: 85, source: "Spaghetti Dinner / Gift Event" },
      { name: "Alyssa Melton", amount: 75, source: "Spaghetti Dinner / Gift Event" },
      { name: "Rick Hansen", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Leisa Elliott", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Raegan Anderson", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Naomi Monschein", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Cristina Pena", amount: 40, source: "Spaghetti Dinner / Gift Event" },
      { name: "Chelsie Anderson", amount: 30, source: "Spaghetti Dinner / Gift Event" },
      { name: "April Ornelas", amount: 25, source: "Spaghetti Dinner / Gift Event" },
      { name: "Amy Cofer", amount: 25, source: "Spaghetti Dinner / Gift Event" },
      { name: "Chelsie Anderson", amount: 20, source: "Spaghetti Dinner / Gift Event" },
      { name: "Matthew Wilson", amount: 20, source: "Spaghetti Dinner / Gift Event" },
      { name: "Dana Ra", amount: 20, source: "Spaghetti Dinner / Gift Event" },
      { name: "Aaron Garcia", amount: 15, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100626,
    firstName: "Dane",
    lastName: "Cimino",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100627,
    firstName: "Giselle",
    lastName: "Davis",
    role: "Member",
    totalRaised: 300,
    tripCost: 1800,
    balanceOwed: 1500,
    donors: [
      { name: "Mark Brown", amount: 200, source: "Spaghetti Dinner / Gift Event" },
      { name: "Mark Turner", amount: 100, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100628,
    firstName: "Sage",
    lastName: "Dawe",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100629,
    firstName: "Bella",
    lastName: "Flores",
    role: "Member",
    totalRaised: 1335,
    tripCost: 1800,
    balanceOwed: 465,
    donors: [
      { name: "David Youd", amount: 1000, source: "Spaghetti Dinner / Gift Event" },
      { name: "Kathryn Segura", amount: 250, source: "Spaghetti Dinner / Gift Event" },
      { name: "Sarah Carter", amount: 60, source: "Spaghetti Dinner / Gift Event" },
      { name: "Rodney Pschier", amount: 25, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100630,
    firstName: "Harry",
    lastName: "Gacias",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100631,
    firstName: "Adam",
    lastName: "Gleeson",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100632,
    firstName: "Matthew",
    lastName: "Gleeson",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100633,
    firstName: "Sita",
    lastName: "Goldstein",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100634,
    firstName: "Eli",
    lastName: "Gorham",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100635,
    firstName: "Noah",
    lastName: "Gorham",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100636,
    firstName: "Catherine",
    lastName: "Johnson",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100637,
    firstName: "Tesiah",
    lastName: "Law",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100638,
    firstName: "Keoni",
    lastName: "Lee",
    role: "Member",
    totalRaised: 0,
    tripCost: 1800,
    balanceOwed: 1800,
    donors: [],
  },
  {
    id: 100639,
    firstName: "Samantha",
    lastName: "Liu",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100640,
    firstName: "Seth",
    lastName: "Liu",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100641,
    firstName: "Aliz",
    lastName: "Lundbom",
    role: "Member",
    totalRaised: 1700,
    tripCost: 1800,
    balanceOwed: 100,
    donors: [
      { name: "Aliz Lundbom", amount: 950, source: "Fundraising Contribution" },
      { name: "Patrick Lundbom", amount: 400, source: "Fundraising Contribution" },
      { name: "Ilona Voloscsuk", amount: 150, source: "Fundraising Contribution" },
      { name: "JP Genoud", amount: 150, source: "Fundraising Contribution" },
      { name: "Aliz Lundbom", amount: 50, source: "Fundraising Contribution" },
    ],
  },
  {
    id: 100642,
    firstName: "Taylor",
    lastName: "Madu",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100643,
    firstName: "Lucca",
    lastName: "Marin",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100644,
    firstName: "Niccolo",
    lastName: "Marin",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100645,
    firstName: "Sofia Ann",
    lastName: "Morgia",
    role: "Member",
    totalRaised: 890,
    tripCost: 1800,
    balanceOwed: 910,
    donors: [
      { name: "Aliz Lundbom", amount: 495, source: "Fundraising Contribution" },
      { name: "Chris Morgia", amount: 200, source: "Fundraising Contribution" },
      { name: "Edith Davis", amount: 100, source: "Fundraising Contribution" },
      { name: "Leslie Esquivel", amount: 75, source: "Fundraising Contribution" },
      { name: "Eric Ra", amount: 10, source: "Spaghetti Dinner / Gift Event" },
      { name: "AJ Malaca", amount: 10, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100646,
    firstName: "Jaden",
    lastName: "Ng",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100647,
    firstName: "William",
    lastName: "Sharland",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100648,
    firstName: "Scarlett",
    lastName: "Silz",
    role: "Member",
    totalRaised: 0,
    tripCost: 1800,
    balanceOwed: 1800,
    donors: [],
  },
  {
    id: 100649,
    firstName: "Rebekah",
    lastName: "Spencer",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100650,
    firstName: "Eva Rachel",
    lastName: "Thomas",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100651,
    firstName: "Lucia",
    lastName: "Ticas",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [
      { name: "Martin Ticas", amount: 100, source: "Fundraising Contribution" },
    ],
  },
  {
    id: 100652,
    firstName: "Martin",
    lastName: "Ticas",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Martin Ticas", amount: 100, source: "Fundraising Contribution" }],
  },
  {
    id: 100653,
    firstName: "John",
    lastName: "Trainer",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100654,
    firstName: "Audrey",
    lastName: "Watts",
    role: "Member",
    totalRaised: 770,
    tripCost: 1800,
    balanceOwed: 1030,
    donors: [
      { name: "Valerie Watts", amount: 500, source: "Fundraising Contribution" },
      { name: "James Watts", amount: 100, source: "Fundraising Contribution" },
      { name: "Eric Totman", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Cindy Matteoni", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Ted Nakamura", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Becky Fitch", amount: 20, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100655,
    firstName: "Daniel",
    lastName: "Watts",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
  {
    id: 100656,
    firstName: "Sydney",
    lastName: "Watts",
    role: "Member",
    totalRaised: 970,
    tripCost: 1800,
    balanceOwed: 830,
    donors: [
      { name: "Val Watts", amount: 500, source: "Fundraising Contribution" },
      { name: "Jan La Torre-Derby", amount: 200, source: "Spaghetti Dinner / Gift Event" },
      { name: "James Watts", amount: 100, source: "Fundraising Contribution" },
      { name: "Eric Totman", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Cindy Matteoni", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Ted Nakamura", amount: 50, source: "Spaghetti Dinner / Gift Event" },
      { name: "Becky Fitch", amount: 20, source: "Spaghetti Dinner / Gift Event" },
    ],
  },
  {
    id: 100657,
    firstName: "Allison",
    lastName: "Wong",
    role: "Member",
    totalRaised: 100,
    tripCost: 1800,
    balanceOwed: 1700,
    donors: [{ name: "Registration", amount: 100, source: "Registration Deposit" }],
  },
];

export const PALETTE = [
  "#C4714A",
  "#3B7D6E",
  "#2D4468",
  "#D4A84B",
  "#7B5EA7",
  "#4A8AB5",
  "#B85E7A",
  "#6B8E4E",
];

export function getColor(name: string): string {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffff;
  return PALETTE[h % PALETTE.length];
}

export function getInitials(person: Person): string {
  const words = (person.firstName + " " + person.lastName).split(" ").filter(Boolean);
  return (words[0][0] + (words[1]?.[0] || "")).toUpperCase();
}

export function formatCurrency(n: number): string {
  return "$" + Math.round(n).toLocaleString();
}

export function getPercentage(person: Person): number {
  return Math.min(100, Math.round((person.totalRaised / TRIP_COST) * 100));
}

export type FundingStatus = "funded" | "overfunded" | "partial" | "none";

export function getStatus(person: Person): FundingStatus {
  if (person.role === "Staff") return "funded";
  if (person.totalRaised >= TRIP_COST * 1.01) return "overfunded";
  if (person.totalRaised >= TRIP_COST) return "funded";
  if (person.totalRaised === 0) return "none";
  return "partial";
}

export function getProgressColor(person: Person): string {
  const s = getStatus(person);
  if (s === "overfunded") return "#D4A84B";
  if (s === "funded") return "#3B7D6E";
  if (s === "none") return "#D0D8E4";
  const v = getPercentage(person);
  return v < 15 ? "#D95F4B" : v < 50 ? "#E89070" : "#C4714A";
}

export function getSourceTag(source: string): { emoji: string; label: string; className: string } {
  if (source === "Registration Deposit") {
    return { emoji: "📋", label: "Registration Deposit", className: "bg-navy/5 text-navy-mid" };
  }
  if (source === "Fundraising Contribution") {
    return { emoji: "💝", label: "Direct Contribution", className: "bg-teal-light text-teal" };
  }
  if (source === "House Build Contribution") {
    return { emoji: "🔨", label: "House Build Fund", className: "bg-gold-pale text-[#8A6010]" };
  }
  if (source === "General Fund Donation") {
    return { emoji: "🌟", label: "General Fund", className: "bg-gold/25 text-[#7A5010]" };
  }
  if (source === "Overflow — Exceeded Goal") {
    return { emoji: "➡️", label: "Transferred Overflow", className: "bg-teal/10 text-teal" };
  }
  return { emoji: "🍝", label: "Spaghetti Dinner / Gift Event", className: "bg-clay-pale text-clay" };
}

// Process overflow: move excess funds to team fund
export function processOverflow(people: Person[], teamFund: TeamFund): { people: Person[]; teamFund: TeamFund } {
  const processedPeople = people.map((p) => {
    if (p.role === "Staff") return p;
    const overflow = p.totalRaised - TRIP_COST;
    if (overflow > 0) {
      return {
        ...p,
        totalRaised: TRIP_COST,
        balanceOwed: 0,
      };
    }
    return p;
  });

  const overflowDonors: Donor[] = [];
  let additionalFunds = 0;

  people.forEach((p) => {
    if (p.role === "Staff") return;
    const overflow = p.totalRaised - TRIP_COST;
    if (overflow > 0) {
      overflowDonors.push({
        name: `${p.firstName} ${p.lastName} (overflow)`,
        amount: overflow,
        source: "Overflow — Exceeded Goal",
      });
      additionalFunds += overflow;
    }
  });

  const processedTeamFund: TeamFund = {
    totalRaised: teamFund.totalRaised + additionalFunds,
    donors: [...teamFund.donors, ...overflowDonors],
  };

  return { people: processedPeople, teamFund: processedTeamFund };
}
