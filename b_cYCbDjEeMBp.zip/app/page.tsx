"use client";

import { useState, useMemo } from "react";
import { PEOPLE, TEAM_FUND, TRIP_COST, Person, TeamFund, formatCurrency, getStatus, getPercentage, processOverflow, FundingStatus } from "@/lib/data";
import { PersonCard } from "@/components/person-card";
import { TeamFundCard } from "@/components/team-fund-card";
import { PersonModal } from "@/components/person-modal";

type FilterType = "all" | "funded" | "partial" | "none";
type SortType = "name" | "raised-desc" | "raised-asc" | "pct-desc" | "owed-desc";

export default function FundraisingTracker() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [sort, setSort] = useState<SortType>("name");
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [showTeamFund, setShowTeamFund] = useState(false);

  // Process overflow funds
  const { people, teamFund } = useMemo(() => processOverflow(PEOPLE, TEAM_FUND), []);

  // Calculate stats
  const stats = useMemo(() => {
    const totalRaised = people.reduce((s, p) => s + p.totalRaised, 0) + teamFund.totalRaised;
    const students = people.filter((p) => p.role !== "Staff");
    const totalOwed = students.reduce((s, p) => s + p.balanceOwed, 0);
    const fullyFunded = people.filter((p) => p.totalRaised >= TRIP_COST).length;
    const pct = Math.round((totalRaised / (people.length * TRIP_COST)) * 100);
    return { totalRaised, studentCount: students.length, totalOwed, fullyFunded, pct };
  }, [people, teamFund]);

  // Filter and sort people
  const filteredPeople = useMemo(() => {
    let list = [...people];
    const q = searchQuery.toLowerCase().trim();

    // Filter by status
    if (filter !== "all") {
      list = list.filter((p) => {
        const s = getStatus(p);
        if (filter === "funded") return s === "funded" || s === "overfunded";
        if (filter === "partial") return s === "partial";
        if (filter === "none") return s === "none";
        return true;
      });
    }

    // Search
    if (q) {
      list = list.filter(
        (p) =>
          (p.firstName + " " + p.lastName).toLowerCase().includes(q) ||
          p.donors.some((d) => d.name.toLowerCase().includes(q))
      );
    }

    // Sort
    if (sort === "name") list.sort((a, b) => a.lastName.localeCompare(b.lastName));
    else if (sort === "raised-desc") list.sort((a, b) => b.totalRaised - a.totalRaised);
    else if (sort === "raised-asc") list.sort((a, b) => a.totalRaised - b.totalRaised);
    else if (sort === "pct-desc") list.sort((a, b) => getPercentage(b) - getPercentage(a));
    else if (sort === "owed-desc") list.sort((a, b) => b.balanceOwed - a.balanceOwed);

    return list;
  }, [people, filter, searchQuery, sort]);

  const staff = filteredPeople.filter((p) => p.role === "Staff");
  const members = filteredPeople.filter((p) => p.role !== "Staff");

  // Show team fund only when filter is "all" and search matches
  const showTeamFundCard = useMemo(() => {
    if (filter !== "all") return false;
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      "general team fund".includes(q) ||
      teamFund.donors.some((d) => d.name.toLowerCase().includes(q))
    );
  }, [filter, searchQuery, teamFund.donors]);

  const filterButtons: { label: string; value: FilterType; icon: string }[] = [
    { label: "All", value: "all", icon: "" },
    { label: "Funded", value: "funded", icon: "✅" },
    { label: "In Progress", value: "partial", icon: "🔶" },
    { label: "Not Started", value: "none", icon: "⚪" },
  ];

  return (
    <div className="min-h-screen bg-sand text-text">
      {/* Header */}
      <header className="bg-navy px-10 pt-12 pb-10 text-center relative overflow-hidden max-sm:px-5 max-sm:pt-8 max-sm:pb-7">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_50%,rgba(196,113,74,0.25)_0%,transparent_65%),radial-gradient(ellipse_at_20%_80%,rgba(59,125,110,0.2)_0%,transparent_55%)] pointer-events-none" />
        <div className="text-[11px] font-semibold tracking-[3px] uppercase text-clay-light mb-3 relative">
          Cornerstone Fellowship · June 16–23, 2026
        </div>
        <h1 className="font-serif text-[clamp(28px,5vw,48px)] font-bold text-white leading-tight relative">
          YWAM Ensenada 2026
          <br />
          Fundraising Tracker
        </h1>
        <div className="mt-3 text-[13px] font-light text-white/55 italic relative">
          &quot;Serve one another in love.&quot; — Galatians 5:13b
        </div>
        <div className="flex justify-center gap-8 mt-8 flex-wrap relative max-sm:gap-4">
          <div className="bg-white/[0.08] border border-white/[0.12] rounded-full px-5 py-2 text-[13px] font-medium text-white/80">
            📍 <strong className="text-white">Ensenada, Baja California</strong>
          </div>
          <div className="bg-white/[0.08] border border-white/[0.12] rounded-full px-5 py-2 text-[13px] font-medium text-white/80">
            🏠 <strong className="text-white">Home Build Mission</strong>
          </div>
          <div className="bg-white/[0.08] border border-white/[0.12] rounded-full px-5 py-2 text-[13px] font-medium text-white/80">
            🎯 <strong className="text-white">$1,800</strong> per person
          </div>
        </div>
      </header>

      {/* Summary Strip */}
      <div className="bg-white border-b border-sand-dark px-10 py-5 flex justify-center flex-wrap max-sm:px-5 max-sm:py-3.5">
        <div className="text-center px-9 border-r border-sand-dark max-sm:px-3.5">
          <div className="font-serif text-[26px] font-bold text-navy leading-none">{stats.studentCount}</div>
          <div className="text-[11px] font-medium tracking-[1.5px] uppercase text-text-light mt-1">Students</div>
        </div>
        <div className="text-center px-9 border-r border-sand-dark max-sm:px-3.5">
          <div className="font-serif text-[26px] font-bold text-teal leading-none">
            {formatCurrency(stats.totalRaised)}
          </div>
          <div className="text-[11px] font-medium tracking-[1.5px] uppercase text-text-light mt-1">Total Raised</div>
        </div>
        <div className="text-center px-9 border-r border-sand-dark max-sm:px-3.5">
          <div className="font-serif text-[26px] font-bold text-clay leading-none">
            {formatCurrency(stats.totalOwed)}
          </div>
          <div className="text-[11px] font-medium tracking-[1.5px] uppercase text-text-light mt-1">Still Needed</div>
        </div>
        <div className="text-center px-9 border-r border-sand-dark max-sm:px-3.5">
          <div className="font-serif text-[26px] font-bold text-navy leading-none">{stats.fullyFunded}</div>
          <div className="text-[11px] font-medium tracking-[1.5px] uppercase text-text-light mt-1">Fully Funded</div>
        </div>
        <div className="text-center px-9 max-sm:px-3.5">
          <div className="font-serif text-[26px] font-bold text-navy leading-none">{stats.pct}%</div>
          <div className="text-[11px] font-medium tracking-[1.5px] uppercase text-text-light mt-1">Overall Progress</div>
        </div>
      </div>

      {/* Controls */}
      <div className="px-10 pt-6 pb-2 flex gap-3 flex-wrap items-center max-w-[1400px] mx-auto max-sm:px-5 max-sm:pt-4">
        <div className="relative flex-1 min-w-[200px] max-w-[320px]">
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 text-text-light"
            width="15"
            height="15"
            viewBox="0 0 20 20"
            fill="none"
          >
            <circle cx="9" cy="9" r="6" stroke="currentColor" strokeWidth="1.8" />
            <path d="M13.5 13.5L17 17" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            placeholder="Search by name…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full py-2.5 px-3.5 pl-10 border-[1.5px] border-sand-dark rounded-xl font-sans text-sm bg-white text-text outline-none transition-colors focus:border-clay"
          />
        </div>

        <div className="flex gap-2 flex-wrap">
          {filterButtons.map((btn) => (
            <button
              key={btn.value}
              onClick={() => setFilter(btn.value)}
              className={`py-2 px-4 border-[1.5px] rounded-xl font-sans text-[13px] font-medium cursor-pointer transition-all ${
                filter === btn.value
                  ? "bg-clay text-white border-clay"
                  : "bg-white text-text-mid border-sand-dark hover:border-clay hover:text-clay"
              }`}
            >
              {btn.icon && <span className="mr-1">{btn.icon}</span>}
              {btn.label}
            </button>
          ))}
        </div>

        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortType)}
          className="py-2 px-3.5 pr-7 border-[1.5px] border-sand-dark rounded-xl font-sans text-[13px] font-medium bg-white text-text-mid cursor-pointer outline-none appearance-none bg-[url('data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%2712%27%20height%3D%278%27%20fill%3D%27none%27%3E%3Cpath%20d%3D%27M1%201l5%205%205-5%27%20stroke%3D%27%238A9BB5%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%2F%3E%3C%2Fsvg%3E')] bg-[position:right_10px_center] bg-no-repeat"
        >
          <option value="name">Sort: Name</option>
          <option value="raised-desc">Sort: Most Raised</option>
          <option value="raised-asc">Sort: Least Raised</option>
          <option value="pct-desc">Sort: % Complete</option>
          <option value="owed-desc">Sort: Most Owed</option>
        </select>
      </div>

      {/* Grid */}
      <div className="px-10 pt-4 pb-16 max-w-[1400px] mx-auto max-sm:px-5 max-sm:pt-3 max-sm:pb-10">
        {/* Team Fund Section */}
        {showTeamFundCard && (
          <>
            <div className="text-[11px] font-semibold tracking-[2.5px] uppercase text-text-light my-5 pl-0.5">
              Team Fund
            </div>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4">
              <TeamFundCard teamFund={teamFund} onClick={() => setShowTeamFund(true)} />
            </div>
          </>
        )}

        {/* Staff Section */}
        {staff.length > 0 && (
          <>
            <div className="text-[11px] font-semibold tracking-[2.5px] uppercase text-text-light my-5 pl-0.5">
              Staff ({staff.length})
            </div>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4">
              {staff.map((person) => (
                <PersonCard key={person.id} person={person} onClick={() => setSelectedPerson(person)} />
              ))}
            </div>
          </>
        )}

        {/* Members Section */}
        {members.length > 0 && (
          <>
            <div className="text-[11px] font-semibold tracking-[2.5px] uppercase text-text-light my-5 pl-0.5">
              Students & Team Members ({members.length})
            </div>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4">
              {members.map((person) => (
                <PersonCard key={person.id} person={person} onClick={() => setSelectedPerson(person)} />
              ))}
            </div>
          </>
        )}

        {/* No Results */}
        {!showTeamFundCard && staff.length === 0 && members.length === 0 && (
          <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4">
            <div className="col-span-full text-center py-16 px-5 text-text-light text-[15px]">
              No results found.
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      <PersonModal
        person={selectedPerson}
        teamFund={showTeamFund ? teamFund : null}
        isOpen={!!selectedPerson || showTeamFund}
        onClose={() => {
          setSelectedPerson(null);
          setShowTeamFund(false);
        }}
      />
    </div>
  );
}
